﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpriteSheet
{
   class Animation
   {
      Texture2D texture;
      Rectangle rectangle;
      Vector2 velocity;
      Vector2 position;
      Vector2 origin;

      float Interval = 85;
      float timer;

      int currentFrame;
      int frameHeight;
      int frameWidth;

      public Animation(Texture2D newTexture, Vector2 newPosition, int newFrameHeight, int newFrameWidth)
      {
         texture = newTexture;
         position = newPosition;
         frameWidth = newFrameWidth;
         frameHeight = newFrameHeight;


      }
          




public void Update(GameTime gameTime)
{
   rectangle = new Rectangle(currentFrame * frameWidth, 0, frameWidth, frameHeight);
   origin = new Vector2(frameWidth / 2, frameHeight / 2);
   position = position + velocity;
   if (position.X <= 100) position.X = 100;
   if (position.X >= 1700) position.X = 1700; 

   if (Keyboard.GetState().IsKeyDown(Keys.Right))
   {
      animateRight(gameTime);
      velocity.X = 5;
   }
   else if
      (Keyboard.GetState().IsKeyDown(Keys.Left))
   {
      animateLeft(gameTime);
      velocity.X = -5;
   }
   else velocity=Vector2.Zero;
}
public void animateRight(GameTime gameTime)
{
   timer += (float)gameTime.ElapsedGameTime.TotalMilliseconds/4;
   if (timer > Interval)
   {
      // current frame goes up
      currentFrame++;
      //timer gets reset to zero
      timer = 0;
      // reaches three resets back to zero (loop) for animation
      if (currentFrame > 5)
         currentFrame = 0;
   }
}

         public void animateLeft (GameTime gameTime)
         {
            timer+=(float)gameTime.ElapsedGameTime.TotalMilliseconds/4;
            if (timer>Interval)
            {
// current frame goes up
               currentFrame++;
//timer gets reset to zero
               timer=0;
// reaches three resets back to zero (loop) for animation
               if(currentFrame> 11 || currentFrame < 6)
                  currentFrame=6;
            }
         }
         

         public void Draw(SpriteBatch spriteBatch)
         {
            spriteBatch.Draw(texture, position, rectangle, Color.White, 0.0f, origin, 0.5f, SpriteEffects.None, 0);

         }
        
      }
   }

